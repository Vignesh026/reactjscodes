import React from "react";
import ReactDOM from "react-dom";
import One from './App'

function Class()
{
  return (
    <One/>
  )
}
ReactDOM.render(<Class/>,document.getElementById("root"));

